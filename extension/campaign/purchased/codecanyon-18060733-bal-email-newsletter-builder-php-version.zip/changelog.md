﻿Bal - Email Newsletter Builder


1.4 | 12.11.2016
Added: Multiuser system (user and admin interface)
Fixed: minor bugs


1.3 | 01.11.2016
Fixed: Image-full,Price table,Image 2 elements make compatible Outlook 2013
Added: Email builder jQuery plugin 50+ different options
Added: 5 language support

1.2 | 19.10.2016
Fixed: 'Select image' popup with a scroll
Added: Jumbotron,Features,Service List,Address Logo,Price Table element
Added: Edit any element with source code


1.1 | 13.10.2016
----------
Added: Context menu -  put link in text,change font-size,font-family and other functionalities
Added: Send Email via PhpMailer
Added: Change Email Width
Added: Change Image size
Added: Create blank page
Added: 2 Image column element


1.0 | 23.09.2016
----------
Created
