  <html>
        <head>
            <title>redirect pay2go ...</title>
        </head> 
        
        <body>
            {!! $order !!}
        </body>
    </html>