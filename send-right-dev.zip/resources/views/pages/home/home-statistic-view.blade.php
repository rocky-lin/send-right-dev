@if(empty($statistics)) 
	<br><br><br><br>
	<center>
		No analytics yet...
	</center>
@else
	<div class="list-group">    
	 	<a href="#" class="list-group-item">   </a>   
	  <br>
	  <center><a href="#">view more..</a></center>
	</div> 
@endif