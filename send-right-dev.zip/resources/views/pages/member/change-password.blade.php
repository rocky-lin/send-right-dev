
			<form class="form-horizontal">
				<fieldset> 
				<!-- Form Name -->
				<legend>Change password</legend> 
				<!-- Password input-->
				<div class="form-group" style="display:none ">
				  <label class="col-md-4 control-label" for="piCurrPass">Current Password 1</label>
				  <div class="col-md-4">
				    <input id="piCurrPass" name="piCurrPass" type="password" placeholder="" class="form-control input-md" required=""> 
				  </div>
				</div>

				<!-- Password input-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="piNewPass">New Password</label>
				  <div class="col-md-4">
				    <input id="piNewPass" name="piNewPass" type="password" placeholder="" class="form-control input-md" required=""> 
				  </div>
				</div> 
				<!-- Password input-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="piNewPassRepeat">Repeat New Password</label>
				  <div class="col-md-4">
				    <input id="piNewPassRepeat" name="piNewPassRepeat" type="password" placeholder="" class="form-control input-md" required=""> 
				  </div>
				</div> 
				<!-- Button (Double) -->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="bCancel"></label>
				  <div class="col-md-8"> 
				    <button id="bGodkend" name="bGodkend" class="btn btn-success">Update</button>
				  </div>
				</div> 
				</fieldset>
				</form>