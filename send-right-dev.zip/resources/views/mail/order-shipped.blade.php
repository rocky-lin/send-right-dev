<!DOCTYPE html>
<html>
<head>
	<title> Test </title>
</head>
<body>
	Testing email from mailable class
</body>
</html>