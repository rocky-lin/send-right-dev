<!DOCTYPE html>
<html>
<head>
	<title> This is the email </title>
</head>
<body>
	Hi  {{ $name }} there thank you for registering our service! 
	please click this link to confirm your registrations!
</body>
</html>