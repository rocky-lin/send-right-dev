console.log("javascript loaded!...")

function click() {
	alert("clicked delete");
}


