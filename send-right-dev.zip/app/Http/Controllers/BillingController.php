<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BillingController extends Controller
{
    public function processSelectProduct()
    {




        print "process select plan here";
    }
}
