<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Account extends Model
{ 
	protected $table = 'accounts';
 	
	public function formLists() 
    {
        return $this->hasManyThrough('App\FormList', 'App\Form', 'account_id', 'form_id', 'id');
    }     

 	public function user_acounts(){
		return $this->hasMany('App\UserAccount');
 	}
 	public function contacts() {
 		return $this->hasMany('App\Contact');
 	}
 	public function forms(){
 		return $this->hasMany('App\Form', 'account_id', 'id');
 	}
}
