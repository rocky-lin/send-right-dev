<?php 
 
function getCurrentDateTime() {
	return date('Y-m-d H:i:s');
}