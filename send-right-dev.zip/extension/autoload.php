<?php  
require ('custom-framework/helper.php');
require ('custom-framework/Model/Model.php');
require ('custom-framework/Model/User.php');
require ('custom-framework/Model/Form.php'); 
require ('custom-framework/Model/FormEntry.php');  
require ('custom-framework/Model/Contact.php');
require ('custom-framework/Model/FormList.php');   
require ('custom-framework/Model/ListContact.php');   
require ('custom-framework/Model/List.php');   


require ('custom-framework/Controller/FormController.php');
require ('custom-framework/Controller/FormEntryController.php');
 
