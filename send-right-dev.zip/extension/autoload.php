<?php  
require ('custom-framework/Model/Model.php');
require ('custom-framework/Model/User.php');
require ('custom-framework/Model/Form.php'); 

require ('custom-framework/Controller/FormController.php');
