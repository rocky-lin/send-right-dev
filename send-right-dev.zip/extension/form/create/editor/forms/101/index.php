<!DOCTYPE html>

<html>

<head>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">

<meta charset="utf-8">

<title>another form the redirect after signup</title>


<!-- Form Start -->

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

<script src="cfgen-form-101/js/form.js"></script>
<link href="cfgen-form-101/css/form.css" rel="stylesheet" type="text/css">

<!-- Form End -->


</head>

<body>

<div class="cfgen-form-container" id="cfgen-form-101">

<div class="cfgen-form-content">

<div class="cfgen-e-c">
	<div class="cfgen-title" id="cfgen-element-101-1">Contact us</div>
</div>


<div class="cfgen-e-c">

	<div class="cfgen-e-set" id="cfgen-element-101-2-set-c">
	</div>

</div>


<div class="cfgen-e-c">

	<label class="cfgen-label" id="cfgen-element-101-6-label" ><span class="cfgen-label-value">First Name</span></label>

	<div class="cfgen-e-set" id="cfgen-element-101-6-set-c">
		<div class="cfgen-input-group" id="cfgen-element-101-6-inputgroup-c">
			<div class="cfgen-input-c" id="cfgen-element-101-6-input-c">
				<input type="text" class="cfgen-type-text cfgen-form-value " name="cfgen-element-101-6" id="cfgen-element-101-6">
			</div>
		</div>
	</div>

	<div class="cfgen-clear"></div>

</div>


<div class="cfgen-e-c">

	<label class="cfgen-label" id="cfgen-element-101-3-label" ><span class="cfgen-label-value">Email address</span><span class="cfgen-required">*</span></label>

	<div class="cfgen-e-set" id="cfgen-element-101-3-set-c">
		<div class="cfgen-input-group" id="cfgen-element-101-3-inputgroup-c">
			<div class="cfgen-input-c" id="cfgen-element-101-3-input-c">
				<input type="text" class="cfgen-type-email cfgen-form-value " name="cfgen-element-101-3" id="cfgen-element-101-3">
			</div>
		</div>
	</div>

	<div class="cfgen-clear"></div>

</div>


<div class="cfgen-e-c">

	<div class="cfgen-e-set" id="cfgen-element-101-5-set-c">
		<div class="cfgen-input-group" id="cfgen-element-101-5-inputgroup-c">
			<div class="cfgen-input-c" id="cfgen-element-101-5-input-c">
				<input type="submit" class="cfgen-submit" name="cfgen-element-101-5" id="cfgen-element-101-5" value="Send">
			</div>
		</div>
	</div>

</div>


<div class="cfgen-loading"></div>

</div><!-- cfgen-form-content -->

</div><!-- cfgen-form-container -->

</body>


</html>