<?php if(empty($contacts)): ?> 
	<br><br><br><br>
	<center>
	No contacts yet...
	</center>
<?php else: ?>   
	<div class="list-group">     
		<?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	 	<a href="#" class="list-group-item"> <?php echo e($contact['first_name'] . ' ' . $contact['last_name'] .' '. $contact['create_at_ago']); ?>  </a>   
	 	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	  <br>
	  <center><a href="<?php echo e(route('contact.index')); ?>">view more..</a></center>
	</div> 
<?php endif; ?>