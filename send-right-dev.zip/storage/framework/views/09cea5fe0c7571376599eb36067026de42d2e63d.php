 
<?php $__env->startSection('content'); ?>
<div class="container"> 
    <div class="row">
        <div class="col-sm-12"> 
            <div class="panel panel-default">  
                <div class="panel-heading"><h4>Select Campaign Type</h4></div>   
                <div class="panel-body">
					<?php echo $__env->make('errors.error-status', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<div class="row"> 
						<div class="col-sm-12" >
						<div class="list-group">

							<?php echo e(Form::open(['url'=>route('campaign.create'), 'method'=>'get'])); ?>

								<input type="hidden" value="newsletter" name="ck">
								<button type="submit" class="list-group-item">
									<div>
										<img src="<?php echo e(url('/public/img/icon/campaign.png')); ?>" />
									</div>
									<label>Create Newsletter</label>
							  </button>
							<?php echo e(Form::close()); ?>


							<?php echo e(Form::open(['url'=>route('campaign.create'), 'method'=>'get'])); ?>

								<input type="hidden" value="auto responder" name="ck">
								<button type="submit" class="list-group-item">
								<div>
									<img src="<?php echo e(url('/public/img/icon/autoresponse.png')); ?>" />
								</div>
								<label>Create auto responder</label>
								</button>
							<?php echo e(Form::close()); ?>


							<?php echo e(Form::open(['url'=>route('campaign.create'), 'method'=>'get'])); ?>

							<input type="hidden" value="mobile email optin" name="ck">
							<button type="submit" class="list-group-item">
								<div>
									<img src="<?php echo e(url('/public/img/campaign/optin.jpg')); ?>" />
								</div>
								<label>Create email optin</label>
							</button>
							<?php echo e(Form::close()); ?>

						</div>
					</div>
				</div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>