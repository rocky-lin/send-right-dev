

<?php if(empty($activities)): ?> 
	<br><br><br><br>
	<center>
	No activities yet...
	</center>
<?php else: ?>
	<div class="list-group">  
	<?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $activity): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> 
	 	<a href="#" class="list-group-item"> <?php echo e($activity['action']); ?> <?php echo e($activity['create_at_ago']); ?> </a> 
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>  
	  <br>
	  <center><a href="#">view more..</a></center>
	</div> 
<?php endif; ?>