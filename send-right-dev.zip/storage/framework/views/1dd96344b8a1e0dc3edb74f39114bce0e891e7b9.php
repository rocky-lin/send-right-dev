  <html>
        <head>
            <title>redirect pay2go ...</title>
        </head> 
        
        <body>
            <?php echo $order; ?>

        </body>
    </html>