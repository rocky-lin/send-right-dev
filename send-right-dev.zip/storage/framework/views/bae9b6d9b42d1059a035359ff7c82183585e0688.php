 	<div class="form-group"> 
		<?php echo e(Form::label('name', null, ['class' => 'control-label'])); ?>

		<?php echo Form::text('name', (!empty($list->name)) ? $list->name : null, ['class'=>'form-control']); ?>

	</div>

	<div class="form-group"> 
		<?php echo e(Form::label('reminder', null, ['class' => 'control-label'])); ?>

		<?php echo Form::text('reminder', (!empty($list->reminder)) ? $list->reminder : null, ['class'=>'form-control']); ?>

	</div> 
	
	<div class="form-group"> 
		<?php echo e(Form::label('url', null, ['class' => 'control-label'])); ?>

		<?php echo Form::text('url', (!empty($list->url)) ? $list->url : null, ['class'=>'form-control']); ?> 
	</div> 

	<div class="form-group"> 
		<?php if(!empty($list)): ?>  
			<?php echo e(Form::submit('Update', ['class'=>'btn btn-info'])); ?>  
		<?php else: ?> 
			<?php echo e(Form::submit('Create', ['class'=>'btn btn-info'])); ?>

		<?php endif; ?>
	</div>   