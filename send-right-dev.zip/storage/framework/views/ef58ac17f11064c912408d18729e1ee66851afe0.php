  

 
<?php 
	
	$stepLists = ['Campaigns'=>'#', 'Campaign Details'=>'#', 'Sender Details'=>'#', 'Compose Campaign'=>'#', 'Campaign Settings'=>'#']; 


	// $stepLists = ['Campaigns'=>route('campaign.index'), 'Campaign Details'=>route('campaign.create'), 'Sender Details'=>route('user.campaign.create.sender.view'), 'Compose Campaign'=>'#', 'Campaign Settings'=>route('user.campaign.create.settings')]; 

?>
<ol class="breadcrumb"> 
	<?php $disableNext = false; ?>
 	<?php $__currentLoopData = $stepLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step => $url): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>  

 		<?php if($step == $currentStep): ?>
			<?php $disableNext = true; ?>
 			<li  class="active" ><?php echo e($step); ?></li>
 		<?php else: ?>  
 			<?php if($disableNext == true): ?>  
 				<li><a href="#"><?php echo e($step); ?></a></li>
 			<?php else: ?> 
				<li><a href="<?php echo e($url); ?>"><?php echo e($step); ?></a></li>
 			<?php endif; ?> 
		<?php endif; ?> 
 	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?> 
</ol>



  
  
