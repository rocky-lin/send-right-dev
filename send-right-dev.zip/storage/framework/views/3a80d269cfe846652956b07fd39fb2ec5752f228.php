<?php if(empty($campaigns)): ?> 
	<br><br><br><br>
	<center>
	No campaigns yet...
	</center>
<?php else: ?>   
	<div class="list-group">   
		<?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	 	<a href="#" class="list-group-item"> <?php echo e($campaign['title'] .' '. $campaign['create_at_ago']); ?>   </a>  
	 	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	  <br>
	  <center><a href="<?php echo e(route('campaign.index')); ?>">view more..</a></center>
	</div> 
<?php endif; ?>