<?php $__env->startSection('content'); ?>
    <div class="container"> 
        <div class="row"> 
        
            <div class="panel panel-default"> 
                <div class="panel-heading"><b>Subscription Billing Confirmation</b></div>   
                <div class="panel-body">   
                    <div class="row ">  
                        <?php echo e(Form::open(['url' => route('user.billing.confirm.proceed'), 'method'=>'post' ] )); ?>  

                             <div class="form-group">  
                                <?php echo e(Form::label('Email', 'Email', ['class'=>'control-label col-sm-2'])); ?> 
                                <div class="col-sm-10">         
                                    <?php echo e(Form::text('Email', Auth::user()->email, ['class'=>'form-control', 'placeholder'=>'Enter Email'] )); ?> 
                                </div>   
                            </div>

                             <br><br><br>
                             <div class="form-group">  
                                <?php echo e(Form::label('Product Name', 'Product Name', ['class'=>'control-label col-sm-2'])); ?> 
                                <div class="col-sm-10">         
                                    <?php echo e(Form::text('productName', $productInfo->name, ['class'=>'form-control', 'placeholder'=>'Enter Email' , 'disabled'] )); ?> 
                                </div>   
                            </div>   


                            <br><br><br>
                             <div class="form-group">  
                                <?php echo e(Form::label('Price', 'Product Price', ['class'=>'control-label col-sm-2'])); ?> 
                                <div class="col-sm-10">         
                                    <?php echo e(Form::text('Price', $productInfo->unit  . ' ' .$productInfo->price, ['class'=>'form-control', 'placeholder'=>'Enter Email', 'disabled'] )); ?> 
                                </div>   
                            </div>


                            <br><br><br>
                            <div class="form-group">  
                                <?php echo e(Form::label('Order Number', 'Order Number', ['class'=>'control-label col-sm-2'])); ?> 
                                <div class="col-sm-10">         
                                    <?php echo e(Form::text('orderNumber', $orderId, ['class'=>'form-control', 'placeholder'=>'Enter Email', 'disabled'] )); ?> 
                                </div>   
                            </div> 

                         <br><br><br>
                            <div class="form-group">  
                                <?php echo e(Form::label('', '', ['class'=>'control-label col-sm-2'])); ?> 
                                <div class="col-sm-10">         
                                    <?php echo e(Form::submit('Proceed', ['class'=>'btn btn-info', 'placeholder'=>'Enter Email'] )); ?> 
                                </div>   
                            </div> 
                            <?php echo e(Form::hidden('name', $productInfo->name, ['class'=>'form-control', 'placeholder'=>'Enter Email'] )); ?>  
                        <?php echo e(Form::close()); ?> 
                    </div>  
                </div>
            </div>  
        </div>
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>