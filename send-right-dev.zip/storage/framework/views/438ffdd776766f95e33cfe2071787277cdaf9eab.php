 
<?php $__env->startSection('content'); ?>
<div class="container"> 
    <div class="row">
        <div class="col-sm-12"> 
            <div class="panel panel-default">  
                <div class="panel-heading">Dashboard</div>    
                <div class="panel-body">    

                    <?php if(session('status_contact')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('status_contact')); ?>

                        </div>
                    <?php endif; ?> 

                    <?php echo $__env->make('pages/include/other/submitted-form-response-one', ['messangeName'=>'status'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
                	<div data-ng-controller="myListCreateViewCtr">       
					    <?php echo Form::open(['route' => 'list.store', 'method'=>'post', 'name'=>'addListFrm', 'autocomplete'=>'off']); ?> 
							<?php echo $__env->make('pages.include.list.list-form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
                            <?php echo $__env->make('pages.include.contact.contact-select', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		            	<?php echo Form::close(); ?>     
                	</div>     
                </div>       
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>