<div class="row">
<div class="col-sm-12">
    <?php if(!Auth::guest()): ?>
        <center> 

        
                <?php if($subscription_status == 1): ?> 
                    <div class="alert alert-info alert-dismissible subscription-status" style="width:103%">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <b> Your subscription is expired!</b>
                    </div>
                <?php elseif($subscription_status == 2): ?>
                    <div class="alert alert-info alert-dismissible subscription-status" style="width:103%">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                         <b> You are currently in trial status, please upgrade now!</b>
                    </div>
                <?php elseif($subscription_status == 4): ?>
                    <div class="alert alert-info alert-dismissible subscription-status" style="width:103%">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                         <b>Your trial subscription is expired </b>
                    </div>
                <?php elseif($subscription_status == 3): ?>
                    
                <?php else: ?>
                    
                <?php endif; ?> 
 



                <?php if(Auth::user()->status == 'inactive'): ?>
                    <div class="alert alert-danger"  style="width:103%" >
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <b>Your account is currently in active, please visit your email and hit comfirm, thank you!</b>
                    </div>
                <?php endif; ?> 


        </center>
    <?php endif; ?>

</div>
</div>

