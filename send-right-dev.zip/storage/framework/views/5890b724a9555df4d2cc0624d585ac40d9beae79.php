 
<?php $__env->startSection('content'); ?>  
<link rel="stylesheet" type="text/css" href="<?php echo e(url('/public/css/billing.css')); ?>" />
<div class="container">
    <div class="container">
        <ul class="nav nav-tabs">
            <li class="active"><a data-toggle="tab" href="#home">Subscription</a></li>
            <li><a data-toggle="tab" href="#menu1">Invoice</a></li>
        </ul>
        <div class="tab-content">
            <div id="home" class="tab-pane fade in active">
                <div class="panel panel-default">
                    <div class="panel-heading" style="text-align: left;">billing</div>
                    <div class="panel-body">
                        <?php echo $__env->make('pages/include/member/billing', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
                    </div>
                </div>
            </div>
            <div id="menu1" class="tab-pane fade">
                List of invoice here..
            </div>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>