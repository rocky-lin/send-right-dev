
  Profile Completed!
  <div class="progress">
      <div class="progress-bar progress-bar-info progress-bar-striped" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:50%">
        50% Complete (info)
      </div>
    </div>

<br><br><br>

<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xs-offset-0 col-sm-offset-0">
    
          <div class="panel ">
            
            <div class="panel-body">
              <div class="row">
                <div class="col-md-3 col-lg-3 " align="center"> <img alt="User Pic" src="http://babyinfoforyou.com/wp-content/uploads/2014/10/avatar-300x300.png" class="img-circle img-responsive"> </div> 
                <div class=" col-md-9 col-lg-9 "> 
                  <table class="table table-user-information">
                    <tbody>
                    <tr>
                      <th style="width:20%">
                        Full Name:
                      </th>
                      <td>  <?php echo e(isset($userInfo['full_name']) ? $userInfo['full_name'] : 'Not yet suplied'); ?> </td>
                    </tr>

                    <tr>
                      <th style="width:20%">
                        Email:
                      </th>
                      <td>  <?php echo e(isset($userInfo['email']) ? $userInfo['email'] : 'Not yet suplied'); ?> </td>
                    </tr>

                    <tr>
                      <th style="width:20%">
                        Company:
                      </th>
                      <td>  <?php echo e(isset($userInfo['company']) ? $userInfo['company'] : 'Not yet suplied'); ?> </td>
                    </tr>


                    <tr>
                      <th style="width:20%">
                        Time Zone:
                      </th>
                      <td>  <?php echo e(isset($userInfo['time_zone']) ? $userInfo['time_zone'] : 'Not yet suplied'); ?> </td>
                    </tr>

                    <tr>
                      <th style="width:20%">
                        Username:
                      </th>
                      <td>  <?php echo e(isset($userInfo['user_name']) ? $userInfo['user_name'] : 'Not yet suplied'); ?> </td>
                    </tr>
                    <tr>
                      <th style="width:20%">
                        Subscription plan billed:
                      </th>
                      <td>  <?php echo e($userInfo['subscription_name'] . ' remaining days till next bill cycle ' . $subscriptionRemainingDaysBilled . ' days'); ?>  </td>
                    </tr>
                 <tr>
                      <th style="width:20%">
                        Subscription plan free:
                      </th>
                      <td>  <?php echo e($userInfo['subscription_name'] . ' your free subscription will expire in ' . $subscriptionRemainingDaysTrial . ' days'); ?>  </td>
                    </tr>

                    </tbody>
                  </table>

                  <a href="<?php echo e(url('user/account')); ?>" class="btn btn-primary">Edit Account</a>
                </div>
              </div>
            </div>
          </div>
        </div>
