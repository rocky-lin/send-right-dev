   
<?php $__env->startSection('content'); ?>

 
<div class="container"  > 
 
<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
    </div>
<?php endif; ?> 
    <div class="row">
        <div class="col-sm-12">     
          <?php echo $__env->make('pages.include.other.campaign-header-steps',  ['currentStep' => 'Sender Details'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          
        <div class="bs-docs-section" ng-controller="myListConnectCtrl">  
          <div class="bs-example" style="padding-bottom: 24px;" append-source> 
                        

                            
                            <?php if(!empty($action)): ?>
                                <?php echo e(Form::open(['url'=>route('user.campaign.sender.update', $id), 'method'=>'post'], ['class'=>'form-control'])); ?>

                            <?php else: ?> 
                                <?php echo e(Form::open(['url'=>route('user.campaign.create.sender.validate'), 'method'=>'post'], ['class'=>'form-control'])); ?>

                            <?php endif; ?> 
                


                <form class="form-inline" role="form">   
                    <div class="form-group"> 
                        <?php echo e(Form::label('Sender Name', 'Sender Name', ['class'=>'label label-primary'])); ?>

                        <?php echo e(Form::text('senderName', (!empty($campaign['sender']['name'])) ? $campaign['sender']['name'] : Auth::user()->name, ['class'=>'form-control', 'placeholder'=>'Sender Name'])); ?> 
                    </div>   
                     <div class="form-group"> 
                        <?php echo e(Form::label('Sender Email', 'Sender Email', ['class'=>'label label-primary'])); ?>

                        <?php echo e(Form::email('senderEmail', (!empty($campaign['sender']['email'])) ? $campaign['sender']['email'] : Auth::user()->email, ['class'=>'form-control', 'placeholder'=>'Sender Email'])); ?> 
                    </div>   
                    <div class="form-group">
                        <?php echo e(Form::label('Email Subject', 'Email Subject', ['class'=>'label label-primary'])); ?>

                         <?php echo e(Form::text('emailSubject', (!empty($campaign['sender']['name'])) ? $campaign['sender']['subject'] : $_SESSION['campaign']['name'], ['class'=>'form-control', 'placeholder'=>'Sender Subject'])); ?> 
                        <br>
                        <div class="form-group">
                            <?php if(!empty($action)): ?>
                                <?php echo e(Form::submit('Next', ['class'=>'btn btn-primary'])); ?>

                            <?php else: ?> 
                                <?php echo e(Form::submit('Update', ['class'=>'btn btn-primary'])); ?>

                            <?php endif; ?> 
                        </div>  
                    <div /> 
            <?php echo e(Form::close()); ?>

            </div> 
        </div>  
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>