  
<?php $__env->startSection('content'); ?>
 
<div class="container"  > 
    <div class="row">
        <div class="col-sm-12">     
        <div class="bs-docs-section" ng-controller="myListConnectCtrl">  
          <div class="bs-example" style="padding-bottom: 24px;" append-source>


                <?php echo e(Form::open(['url'=>route('user.form.register.step1'), 'method'=>'post'], ['class'=>'form-control'])); ?>

                <form class="form-inline" role="form">   
                    <div class="form-group"> 
                        <?php echo e(Form::label('Form Name', 'Form Name', ['class'=>'label label-primary'])); ?>

                        <?php echo e(Form::text('formName', '', ['class'=>'form-control', 'placeholder'=>'Form Name'])); ?> 
                    </div>  
                    <br><br>
                    <div class="form-group">
                        <h3 class="label label-primary" >Select List</h3>
                        <input name='selectedList' type="text" class="form-control" ng-model="selectedAddress" data-min-length="0" data-html="1" data-auto-select="true" data-animation="am-flip-x" bs-options="list as list.name for list in getLists($viewValue)" placeholder="Type keyword" bs-typeahead>
                    </div>    
                    <br><br>
                    <div class="form-group">
                        <?php echo e(Form::label('template', 'Select Form Template', ['class'=>'label label-primary'])); ?>

                        <?php echo e(Form::select('template', ['Default','Business','Blog'], 'list1', ['class'=>'form-control'])); ?> 
                        <br>
                        <div class="form-group">
                            <?php echo e(Form::submit('Next', ['class'=>'btn btn-primary'])); ?>

                        </div>  
                    <div />

            <?php echo e(Form::close()); ?>

            </div> 
        </div>  
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>