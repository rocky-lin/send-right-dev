   
<?php $__env->startSection('content'); ?>

<div class="container"  > 
 
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
        
     <?php if(session('status')): ?>
        <div class="alert alert-danger">
            <ul>
                <li>
                    <?php echo e(session('status')); ?>

                </li>
            </ul>
        </div>
    <?php endif; ?> 

    

    <div class="row">
        <div class="col-sm-12">
            
        <?php echo $__env->make('pages.include.other.campaign-header-steps',  ['currentStep' => 'Campaign Details'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="bs-docs-section" ng-controller="myListConnectCtrl">  
          <div class="bs-example" style="padding-bottom: 24px;" append-source>
 
                


                <?php if(!empty($action)): ?>
                    <?php echo e(Form::open(['url'=>[route('user.campaign.create.update', $id)], 'method'=>'post'], ['class'=>'form-control'])); ?>  
                <?php else: ?>
                    <?php echo e(Form::open(['url'=>route('user.campaign.create.validate'), 'method'=>'post'], ['class'=>'form-control'])); ?>

                <?php endif; ?> 

                <form class="form-inline" role="form"> 
                    <?php echo e(Form::hidden('kind', $kind)); ?>  
                    <div class="form-group"> 
                        <?php echo e(Form::label('Campaign Name', 'Campaign Name', ['class'=>'label label-primary'])); ?>

                        <?php echo e(Form::text('campaignName', (!empty($campaign['title'])) ? $campaign['title'] : '' , ['class'=>'form-control', 'placeholder'=>'Campaign Name'])); ?>

                    </div>  
                    <br><br>  
                    <?php echo $__env->make('pages.include.list.list-select', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
                    <br><br>  
                    <?php if(empty($campaign)): ?>
                        <div class="form-group"> 
                            <?php echo e(Form::label('template', 'Select Campaign Template', ['class'=>'label label-primary'])); ?>

                            <?php echo e(Form::select('template', ['Default' => 'Default','Business'=>'Business','Blog'=>'Blog'], 'list1', ['class'=>'form-control'])); ?> 
                        <div /> 
                    <?php endif; ?> 
                        <br>
                        <div class="form-group">
                            <?php if(!empty($campaign)): ?>
                                <?php echo e(Form::submit('Update', ['class'=>'btn btn-primary'])); ?>

                            <?php else: ?>
                                <?php echo e(Form::submit('Next', ['class'=>'btn btn-primary'])); ?>

                            <?php endif; ?> 
                        </div>   

            <?php echo e(Form::close()); ?>

            </div> 
        </div>  
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>