<?php if(empty($lists)): ?> 
	<br><br><br><br>
	<center>
	No lists yet...
	</center>
<?php else: ?>
	<div class="list-group">   
		<?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $list): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> 
	 		<a href="#" class="list-group-item"> <?php echo e($list['name']); ?> <?php echo e($list['create_at_ago']); ?> </a>  
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>  

	  <br>
	  <center><a href="<?php echo e(route('list.index')); ?>">view more..</a></center>
	</div>
<?php endif; ?>