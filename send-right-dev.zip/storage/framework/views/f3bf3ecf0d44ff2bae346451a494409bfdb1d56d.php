<?php if(empty($forms)): ?> 
	<br><br><br><br>
	<center>
	No forms yet...
	</center>
<?php else: ?>
	<div class="list-group">    
		<?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $from): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> 
	 		<a href="#" class="list-group-item"> <?php echo e($from['name']); ?> <?php echo e($from['create_at_ago']); ?>     </a>  
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>   
	  <br>
	  <center><a href="<?php echo e(route('form.index')); ?>">view more..</a></center>
	</div> 
<?php endif; ?> 