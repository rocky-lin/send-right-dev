
<div style="display:none">
    <?php require ('../index.php'); ?>
</div>

<?php





use App\User;

$users = User::first();
print "test";
print_r($users);





