<?php

print "php info ";
print phpinfo();