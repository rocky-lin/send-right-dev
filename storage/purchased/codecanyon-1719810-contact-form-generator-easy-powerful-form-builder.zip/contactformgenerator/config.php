<?php
$html_section = 'config';

include('index.php');
?>